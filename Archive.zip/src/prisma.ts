import { PrismaClient } from './generated/client'; // از generated استفاده کن

export const prisma = new PrismaClient();