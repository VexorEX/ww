// Global type declarations to resolve missing type definition errors
declare module 'cacheable-request';
declare module 'http-cache-semantics';
declare module 'responselike';
