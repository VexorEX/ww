-- AlterTable
ALTER TABLE "ProductionLine" ADD COLUMN "carName" TEXT;
